import React from "react";
import AppRouter from "./router/index.jsx";

export default function App() {
  return <AppRouter />;
}
